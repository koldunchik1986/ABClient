﻿namespace ABClient.ExtMap
{
    internal class Position
    {
        internal int X { get; set; }
        internal int Y { get; set; }
        internal string RegNum { get; set; }
    }
}
