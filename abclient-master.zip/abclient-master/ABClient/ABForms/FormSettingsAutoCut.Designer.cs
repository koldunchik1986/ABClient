﻿using ABClient.Properties;
namespace ABClient.ABForms
{
    partial class FormSettingsAutoCut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewGroup listViewGroup1 = new System.Windows.Forms.ListViewGroup("Группа 1", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup2 = new System.Windows.Forms.ListViewGroup("Группа 2", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup3 = new System.Windows.Forms.ListViewGroup("Группа 3", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup4 = new System.Windows.Forms.ListViewGroup("Группа 4", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup5 = new System.Windows.Forms.ListViewGroup("Группа 5", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup6 = new System.Windows.Forms.ListViewGroup("Группа 6", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup7 = new System.Windows.Forms.ListViewGroup("Группа 7", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup8 = new System.Windows.Forms.ListViewGroup("Группа 8", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup9 = new System.Windows.Forms.ListViewGroup("Квестовые", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Айва");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Алоэ");
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("Алтей");
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("Амми");
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("Анис");
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem("Антуриум хрустальный");
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem("Аралия");
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem("Арника");
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem("Астрагал");
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem("Бадан");
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem("Бегония");
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem("Береза");
            System.Windows.Forms.ListViewItem listViewItem13 = new System.Windows.Forms.ListViewItem("Бессмертник");
            System.Windows.Forms.ListViewItem listViewItem14 = new System.Windows.Forms.ListViewItem("Болотник");
            System.Windows.Forms.ListViewItem listViewItem15 = new System.Windows.Forms.ListViewItem("Брусника");
            System.Windows.Forms.ListViewItem listViewItem16 = new System.Windows.Forms.ListViewItem("Ведьмино кольцо");
            System.Windows.Forms.ListViewItem listViewItem17 = new System.Windows.Forms.ListViewItem("Вереск");
            System.Windows.Forms.ListViewItem listViewItem18 = new System.Windows.Forms.ListViewItem("Виноград светлый");
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem("Виноград темный");
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem("Галега");
            System.Windows.Forms.ListViewItem listViewItem21 = new System.Windows.Forms.ListViewItem("Гравилат");
            System.Windows.Forms.ListViewItem listViewItem22 = new System.Windows.Forms.ListViewItem("Девясил");
            System.Windows.Forms.ListViewItem listViewItem23 = new System.Windows.Forms.ListViewItem("Дуб");
            System.Windows.Forms.ListViewItem listViewItem24 = new System.Windows.Forms.ListViewItem("Дурман");
            System.Windows.Forms.ListViewItem listViewItem25 = new System.Windows.Forms.ListViewItem("Дягиль");
            System.Windows.Forms.ListViewItem listViewItem26 = new System.Windows.Forms.ListViewItem("Жизненное древо");
            System.Windows.Forms.ListViewItem listViewItem27 = new System.Windows.Forms.ListViewItem("Змеиный Корень");
            System.Windows.Forms.ListViewItem listViewItem28 = new System.Windows.Forms.ListViewItem("Ива");
            System.Windows.Forms.ListViewItem listViewItem29 = new System.Windows.Forms.ListViewItem("Инжир");
            System.Windows.Forms.ListViewItem listViewItem30 = new System.Windows.Forms.ListViewItem("Истод");
            System.Windows.Forms.ListViewItem listViewItem31 = new System.Windows.Forms.ListViewItem("Каланхое");
            System.Windows.Forms.ListViewItem listViewItem32 = new System.Windows.Forms.ListViewItem("Камелия");
            System.Windows.Forms.ListViewItem listViewItem33 = new System.Windows.Forms.ListViewItem("Каперс");
            System.Windows.Forms.ListViewItem listViewItem34 = new System.Windows.Forms.ListViewItem("Карагана");
            System.Windows.Forms.ListViewItem listViewItem35 = new System.Windows.Forms.ListViewItem("Кассия");
            System.Windows.Forms.ListViewItem listViewItem36 = new System.Windows.Forms.ListViewItem("Катарантус");
            System.Windows.Forms.ListViewItem listViewItem37 = new System.Windows.Forms.ListViewItem("Кентарийская дикая роза");
            System.Windows.Forms.ListViewItem listViewItem38 = new System.Windows.Forms.ListViewItem("Кипарис");
            System.Windows.Forms.ListViewItem listViewItem39 = new System.Windows.Forms.ListViewItem("Кипрей");
            System.Windows.Forms.ListViewItem listViewItem40 = new System.Windows.Forms.ListViewItem("Кориандр");
            System.Windows.Forms.ListViewItem listViewItem41 = new System.Windows.Forms.ListViewItem("Коризиус");
            System.Windows.Forms.ListViewItem listViewItem42 = new System.Windows.Forms.ListViewItem("Крестовник");
            System.Windows.Forms.ListViewItem listViewItem43 = new System.Windows.Forms.ListViewItem("Куфис");
            System.Windows.Forms.ListViewItem listViewItem44 = new System.Windows.Forms.ListViewItem("Ландыш");
            System.Windows.Forms.ListViewItem listViewItem45 = new System.Windows.Forms.ListViewItem("Лимон");
            System.Windows.Forms.ListViewItem listViewItem46 = new System.Windows.Forms.ListViewItem("Лиственница");
            System.Windows.Forms.ListViewItem listViewItem47 = new System.Windows.Forms.ListViewItem("Люминсцентная поганка");
            System.Windows.Forms.ListViewItem listViewItem48 = new System.Windows.Forms.ListViewItem("Маклея");
            System.Windows.Forms.ListViewItem listViewItem49 = new System.Windows.Forms.ListViewItem("Моховик");
            System.Windows.Forms.ListViewItem listViewItem50 = new System.Windows.Forms.ListViewItem("Мухомор");
            System.Windows.Forms.ListViewItem listViewItem51 = new System.Windows.Forms.ListViewItem("Осот");
            System.Windows.Forms.ListViewItem listViewItem52 = new System.Windows.Forms.ListViewItem("Парибигус");
            System.Windows.Forms.ListViewItem listViewItem53 = new System.Windows.Forms.ListViewItem("Плаун");
            System.Windows.Forms.ListViewItem listViewItem54 = new System.Windows.Forms.ListViewItem("Поганка");
            System.Windows.Forms.ListViewItem listViewItem55 = new System.Windows.Forms.ListViewItem("Подберезовик");
            System.Windows.Forms.ListViewItem listViewItem56 = new System.Windows.Forms.ListViewItem("Подосиновик");
            System.Windows.Forms.ListViewItem listViewItem57 = new System.Windows.Forms.ListViewItem("Подснежник");
            System.Windows.Forms.ListViewItem listViewItem58 = new System.Windows.Forms.ListViewItem("Прагениана");
            System.Windows.Forms.ListViewItem listViewItem59 = new System.Windows.Forms.ListViewItem("Псоралея");
            System.Windows.Forms.ListViewItem listViewItem60 = new System.Windows.Forms.ListViewItem("Пустынный агапантус");
            System.Windows.Forms.ListViewItem listViewItem61 = new System.Windows.Forms.ListViewItem("Рапонтикум");
            System.Windows.Forms.ListViewItem listViewItem62 = new System.Windows.Forms.ListViewItem("Родиола");
            System.Windows.Forms.ListViewItem listViewItem63 = new System.Windows.Forms.ListViewItem("Секвойя");
            System.Windows.Forms.ListViewItem listViewItem64 = new System.Windows.Forms.ListViewItem("Секуринега");
            System.Windows.Forms.ListViewItem listViewItem65 = new System.Windows.Forms.ListViewItem("Смертоцвет");
            System.Windows.Forms.ListViewItem listViewItem66 = new System.Windows.Forms.ListViewItem("Сосна");
            System.Windows.Forms.ListViewItem listViewItem67 = new System.Windows.Forms.ListViewItem("Софора");
            System.Windows.Forms.ListViewItem listViewItem68 = new System.Windows.Forms.ListViewItem("Сыроежка");
            System.Windows.Forms.ListViewItem listViewItem69 = new System.Windows.Forms.ListViewItem("Тарвин");
            System.Windows.Forms.ListViewItem listViewItem70 = new System.Windows.Forms.ListViewItem("Термопсис");
            System.Windows.Forms.ListViewItem listViewItem71 = new System.Windows.Forms.ListViewItem("Трифоль");
            System.Windows.Forms.ListViewItem listViewItem72 = new System.Windows.Forms.ListViewItem("Фенхель");
            System.Windows.Forms.ListViewItem listViewItem73 = new System.Windows.Forms.ListViewItem("Хвоя");
            System.Windows.Forms.ListViewItem listViewItem74 = new System.Windows.Forms.ListViewItem("Чернокорень");
            System.Windows.Forms.ListViewItem listViewItem75 = new System.Windows.Forms.ListViewItem("Эфедра");
            this.listViewHerbs = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSelectAll = new System.Windows.Forms.Button();
            this.buttonUnselectAll = new System.Windows.Forms.Button();
            this.buttonAccept = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.checkDoAutoCutWriteChat = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // listViewHerbs
            // 
            this.listViewHerbs.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listViewHerbs.CheckBoxes = true;
            this.listViewHerbs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.listViewHerbs.FullRowSelect = true;
            listViewGroup1.Header = "Группа 1";
            listViewGroup1.Name = "listViewGroup1";
            listViewGroup2.Header = "Группа 2";
            listViewGroup2.Name = "listViewGroup2";
            listViewGroup3.Header = "Группа 3";
            listViewGroup3.Name = "listViewGroup3";
            listViewGroup4.Header = "Группа 4";
            listViewGroup4.Name = "listViewGroup4";
            listViewGroup5.Header = "Группа 5";
            listViewGroup5.Name = "listViewGroup5";
            listViewGroup6.Header = "Группа 6";
            listViewGroup6.Name = "listViewGroup6";
            listViewGroup7.Header = "Группа 7";
            listViewGroup7.Name = "listViewGroup7";
            listViewGroup8.Header = "Группа 8";
            listViewGroup8.Name = "listViewGroup8";
            listViewGroup9.Header = "Квестовые";
            listViewGroup9.Name = "listViewGroup9";
            this.listViewHerbs.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup1,
            listViewGroup2,
            listViewGroup3,
            listViewGroup4,
            listViewGroup5,
            listViewGroup6,
            listViewGroup7,
            listViewGroup8,
            listViewGroup9});
            this.listViewHerbs.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listViewHerbs.HotTracking = true;
            this.listViewHerbs.HoverSelection = true;
            listViewItem1.Group = listViewGroup7;
            listViewItem1.StateImageIndex = 0;
            listViewItem1.Tag = "46";
            listViewItem1.ToolTipText = "Зелье Огненного Ореола";
            listViewItem2.Group = listViewGroup6;
            listViewItem2.StateImageIndex = 0;
            listViewItem2.Tag = "74";
            listViewItem2.ToolTipText = "Зелье Секрет Волшебника";
            listViewItem3.Group = listViewGroup4;
            listViewItem3.StateImageIndex = 0;
            listViewItem3.Tag = "58";
            listViewItem3.ToolTipText = "Зелье Мужества";
            listViewItem4.Group = listViewGroup7;
            listViewItem4.StateImageIndex = 0;
            listViewItem4.Tag = "81";
            listViewItem4.ToolTipText = "Зелье Человек-Гора";
            listViewItem5.Group = listViewGroup1;
            listViewItem5.StateImageIndex = 0;
            listViewItem5.Tag = "94";
            listViewItem5.ToolTipText = "Зелье Энергии";
            listViewItem6.Group = listViewGroup2;
            listViewItem6.StateImageIndex = 0;
            listViewItem6.Tag = "113";
            listViewItem6.ToolTipText = "Зелье Невидимости";
            listViewItem7.Group = listViewGroup6;
            listViewItem7.StateImageIndex = 0;
            listViewItem7.Tag = "75";
            listViewItem8.Group = listViewGroup4;
            listViewItem8.StateImageIndex = 0;
            listViewItem8.Tag = "59";
            listViewItem9.Group = listViewGroup4;
            listViewItem9.StateImageIndex = 0;
            listViewItem9.Tag = "60";
            listViewItem9.ToolTipText = "Зелье лечения";
            listViewItem10.Group = listViewGroup2;
            listViewItem10.StateImageIndex = 0;
            listViewItem10.Tag = "87";
            listViewItem10.ToolTipText = "Зелье Сокрушительных Ударов";
            listViewItem11.Group = listViewGroup4;
            listViewItem11.StateImageIndex = 0;
            listViewItem11.Tag = "115";
            listViewItem11.ToolTipText = "Зелье Ловких Ударов";
            listViewItem12.Group = listViewGroup5;
            listViewItem12.StateImageIndex = 0;
            listViewItem12.Tag = "52";
            listViewItem12.ToolTipText = "Зелье Иммунитета";
            listViewItem13.Group = listViewGroup6;
            listViewItem13.StateImageIndex = 0;
            listViewItem13.Tag = "76";
            listViewItem13.ToolTipText = "Зелье Жизни";
            listViewItem14.Group = listViewGroup2;
            listViewItem14.StateImageIndex = 0;
            listViewItem14.Tag = "88";
            listViewItem14.ToolTipText = "Зелье Восстановления Маны";
            listViewItem15.Group = listViewGroup2;
            listViewItem15.StateImageIndex = 0;
            listViewItem15.Tag = "89";
            listViewItem15.ToolTipText = "Зелье Ловкости";
            listViewItem16.Group = listViewGroup6;
            listViewItem16.StateImageIndex = 0;
            listViewItem16.Tag = "80";
            listViewItem16.ToolTipText = "Зелье Восстановления Маны";
            listViewItem17.Group = listViewGroup4;
            listViewItem17.StateImageIndex = 0;
            listViewItem17.Tag = "61";
            listViewItem17.ToolTipText = "Зелье Загрубелой Кожи";
            listViewItem18.Group = listViewGroup8;
            listViewItem18.StateImageIndex = 0;
            listViewItem18.Tag = "118";
            listViewItem19.Group = listViewGroup8;
            listViewItem19.StateImageIndex = 0;
            listViewItem19.Tag = "119";
            listViewItem20.Group = listViewGroup4;
            listViewItem20.StateImageIndex = 0;
            listViewItem20.Tag = "62";
            listViewItem21.Group = listViewGroup6;
            listViewItem21.StateImageIndex = 0;
            listViewItem21.Tag = "77";
            listViewItem21.ToolTipText = "Зелье Сильной Спины";
            listViewItem22.Group = listViewGroup4;
            listViewItem22.StateImageIndex = 0;
            listViewItem22.Tag = "63";
            listViewItem22.ToolTipText = "Зелье Силы";
            listViewItem23.Group = listViewGroup5;
            listViewItem23.StateImageIndex = 0;
            listViewItem23.Tag = "53";
            listViewItem23.ToolTipText = "Зелье загрубелой кожи";
            listViewItem24.Group = listViewGroup4;
            listViewItem24.StateImageIndex = 0;
            listViewItem24.Tag = "64";
            listViewItem25.Group = listViewGroup7;
            listViewItem25.StateImageIndex = 0;
            listViewItem25.Tag = "82";
            listViewItem25.ToolTipText = "Зелье Колкости";
            listViewItem26.Group = listViewGroup3;
            listViewItem26.StateImageIndex = 0;
            listViewItem26.Tag = "104";
            listViewItem26.ToolTipText = "Зелье Лечения";
            listViewItem27.Group = listViewGroup1;
            listViewItem27.StateImageIndex = 0;
            listViewItem27.Tag = "108";
            listViewItem27.ToolTipText = "Зелье Недосягаемости";
            listViewItem28.Group = listViewGroup5;
            listViewItem28.StateImageIndex = 0;
            listViewItem28.Tag = "54";
            listViewItem29.Group = listViewGroup1;
            listViewItem29.StateImageIndex = 0;
            listViewItem29.Tag = "95";
            listViewItem30.Group = listViewGroup4;
            listViewItem30.StateImageIndex = 0;
            listViewItem30.Tag = "66";
            listViewItem30.ToolTipText = "Зелье Ловкости";
            listViewItem31.Group = listViewGroup7;
            listViewItem31.StateImageIndex = 0;
            listViewItem31.Tag = "47";
            listViewItem31.ToolTipText = "Зелье Просветления";
            listViewItem32.Group = listViewGroup4;
            listViewItem32.StateImageIndex = 0;
            listViewItem32.Tag = "111";
            listViewItem32.ToolTipText = "Зелье Огненного Ореола";
            listViewItem33.Group = listViewGroup7;
            listViewItem33.StateImageIndex = 0;
            listViewItem33.Tag = "48";
            listViewItem33.ToolTipText = "Зелье Удачи";
            listViewItem34.Group = listViewGroup4;
            listViewItem34.StateImageIndex = 0;
            listViewItem34.Tag = "65";
            listViewItem34.ToolTipText = "Зелье Медитации";
            listViewItem35.Group = listViewGroup4;
            listViewItem35.StateImageIndex = 0;
            listViewItem35.Tag = "67";
            listViewItem35.ToolTipText = "Зелье Метаболизма";
            listViewItem36.Group = listViewGroup3;
            listViewItem36.StateImageIndex = 0;
            listViewItem36.Tag = "98";
            listViewItem36.ToolTipText = "Зелье Жизни";
            listViewItem37.Group = listViewGroup7;
            listViewItem37.StateImageIndex = 0;
            listViewItem37.Tag = "112";
            listViewItem37.ToolTipText = "Зелье Силы";
            listViewItem38.Group = listViewGroup2;
            listViewItem38.StateImageIndex = 0;
            listViewItem38.Tag = "116";
            listViewItem39.Group = listViewGroup4;
            listViewItem39.StateImageIndex = 0;
            listViewItem39.Tag = "68";
            listViewItem40.Group = listViewGroup7;
            listViewItem40.StateImageIndex = 0;
            listViewItem40.Tag = "49";
            listViewItem40.ToolTipText = "Зелье Боевой Славы";
            listViewItem41.Group = listViewGroup3;
            listViewItem41.StateImageIndex = 0;
            listViewItem41.Tag = "99";
            listViewItem41.ToolTipText = "Зелье Ловкости";
            listViewItem42.Group = listViewGroup7;
            listViewItem42.StateImageIndex = 0;
            listViewItem42.Tag = "50";
            listViewItem42.ToolTipText = "Зелье Лечения Отравлений";
            listViewItem43.Group = listViewGroup3;
            listViewItem43.StateImageIndex = 0;
            listViewItem43.Tag = "100";
            listViewItem44.Group = listViewGroup4;
            listViewItem44.StateImageIndex = 0;
            listViewItem44.Tag = "107";
            listViewItem44.ToolTipText = "Зелье Боевой Славы";
            listViewItem45.Group = listViewGroup4;
            listViewItem45.StateImageIndex = 0;
            listViewItem45.Tag = "114";
            listViewItem45.ToolTipText = "Зелье Блаженства";
            listViewItem46.Group = listViewGroup5;
            listViewItem46.StateImageIndex = 0;
            listViewItem46.Tag = "55";
            listViewItem47.Group = listViewGroup3;
            listViewItem47.StateImageIndex = 0;
            listViewItem47.Tag = "106";
            listViewItem47.ToolTipText = "Зелье Невидимости";
            listViewItem48.Group = listViewGroup2;
            listViewItem48.StateImageIndex = 0;
            listViewItem48.Tag = "90";
            listViewItem48.ToolTipText = "Зелье Энергии";
            listViewItem49.Group = listViewGroup5;
            listViewItem49.StateImageIndex = 0;
            listViewItem49.Tag = "86";
            listViewItem49.ToolTipText = "Зелье Метаболизма";
            listViewItem50.Group = listViewGroup2;
            listViewItem50.StateImageIndex = 0;
            listViewItem50.Tag = "93";
            listViewItem50.ToolTipText = "Яд";
            listViewItem51.Group = listViewGroup1;
            listViewItem51.StateImageIndex = 0;
            listViewItem51.Tag = "96";
            listViewItem51.ToolTipText = "Зелье Блаженства";
            listViewItem52.Group = listViewGroup3;
            listViewItem52.StateImageIndex = 0;
            listViewItem52.Tag = "101";
            listViewItem52.ToolTipText = "Зелье Лечения Отравлений";
            listViewItem53.Group = listViewGroup4;
            listViewItem53.StateImageIndex = 0;
            listViewItem53.Tag = "70";
            listViewItem54.Group = listViewGroup5;
            listViewItem54.StateImageIndex = 0;
            listViewItem54.Tag = "57";
            listViewItem54.ToolTipText = "Яд";
            listViewItem55.Group = listViewGroup5;
            listViewItem55.StateImageIndex = 0;
            listViewItem55.Tag = "56";
            listViewItem55.ToolTipText = "Зелье Удачи";
            listViewItem56.Group = listViewGroup5;
            listViewItem56.StateImageIndex = 0;
            listViewItem56.Tag = "85";
            listViewItem57.Group = listViewGroup9;
            listViewItem57.StateImageIndex = 0;
            listViewItem57.ToolTipText = "Квест";
            listViewItem58.Group = listViewGroup6;
            listViewItem58.StateImageIndex = 0;
            listViewItem58.Tag = "110";
            listViewItem58.ToolTipText = "Зелье Гения";
            listViewItem59.Group = listViewGroup4;
            listViewItem59.StateImageIndex = 0;
            listViewItem59.Tag = "69";
            listViewItem59.ToolTipText = "Зелье Огненного Ореола";
            listViewItem60.Group = listViewGroup1;
            listViewItem60.StateImageIndex = 0;
            listViewItem60.Tag = "109";
            listViewItem61.Group = listViewGroup4;
            listViewItem61.StateImageIndex = 0;
            listViewItem61.Tag = "71";
            listViewItem62.Group = listViewGroup6;
            listViewItem62.StateImageIndex = 0;
            listViewItem62.Tag = "78";
            listViewItem63.Group = listViewGroup3;
            listViewItem63.StateImageIndex = 0;
            listViewItem63.Tag = "105";
            listViewItem63.ToolTipText = "Зелье Человек-Гора";
            listViewItem64.Group = listViewGroup7;
            listViewItem64.StateImageIndex = 0;
            listViewItem64.Tag = "51";
            listViewItem64.ToolTipText = "Зелье Панциря";
            listViewItem65.Group = listViewGroup3;
            listViewItem65.StateImageIndex = 0;
            listViewItem65.Tag = "117";
            listViewItem65.ToolTipText = "Зелье Медитации";
            listViewItem66.Group = listViewGroup5;
            listViewItem66.StateImageIndex = 0;
            listViewItem66.Tag = "83";
            listViewItem66.ToolTipText = "Зелье Просветления";
            listViewItem67.Group = listViewGroup3;
            listViewItem67.StateImageIndex = 0;
            listViewItem67.Tag = "102";
            listViewItem67.ToolTipText = "Зелье Иммунитета";
            listViewItem68.Group = listViewGroup2;
            listViewItem68.StateImageIndex = 0;
            listViewItem68.Tag = "92";
            listViewItem68.ToolTipText = "Зелье Гения";
            listViewItem69.Group = listViewGroup3;
            listViewItem69.StateImageIndex = 0;
            listViewItem69.Tag = "103";
            listViewItem69.ToolTipText = "Зелье Стойкости";
            listViewItem70.Group = listViewGroup6;
            listViewItem70.StateImageIndex = 0;
            listViewItem70.Tag = "79";
            listViewItem70.ToolTipText = "Зелье Секрет Волшебника";
            listViewItem71.Group = listViewGroup2;
            listViewItem71.StateImageIndex = 0;
            listViewItem71.Tag = "91";
            listViewItem71.ToolTipText = "Зелье Точного Попадания";
            listViewItem72.Group = listViewGroup1;
            listViewItem72.StateImageIndex = 0;
            listViewItem72.Tag = "97";
            listViewItem72.ToolTipText = "Зелье Панциря";
            listViewItem73.Group = listViewGroup5;
            listViewItem73.StateImageIndex = 0;
            listViewItem73.Tag = "84";
            listViewItem73.ToolTipText = "Зелье Сильной Спины";
            listViewItem74.Group = listViewGroup4;
            listViewItem74.StateImageIndex = 0;
            listViewItem74.Tag = "72";
            listViewItem75.Group = listViewGroup4;
            listViewItem75.StateImageIndex = 0;
            listViewItem75.Tag = "73";
            this.listViewHerbs.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6,
            listViewItem7,
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12,
            listViewItem13,
            listViewItem14,
            listViewItem15,
            listViewItem16,
            listViewItem17,
            listViewItem18,
            listViewItem19,
            listViewItem20,
            listViewItem21,
            listViewItem22,
            listViewItem23,
            listViewItem24,
            listViewItem25,
            listViewItem26,
            listViewItem27,
            listViewItem28,
            listViewItem29,
            listViewItem30,
            listViewItem31,
            listViewItem32,
            listViewItem33,
            listViewItem34,
            listViewItem35,
            listViewItem36,
            listViewItem37,
            listViewItem38,
            listViewItem39,
            listViewItem40,
            listViewItem41,
            listViewItem42,
            listViewItem43,
            listViewItem44,
            listViewItem45,
            listViewItem46,
            listViewItem47,
            listViewItem48,
            listViewItem49,
            listViewItem50,
            listViewItem51,
            listViewItem52,
            listViewItem53,
            listViewItem54,
            listViewItem55,
            listViewItem56,
            listViewItem57,
            listViewItem58,
            listViewItem59,
            listViewItem60,
            listViewItem61,
            listViewItem62,
            listViewItem63,
            listViewItem64,
            listViewItem65,
            listViewItem66,
            listViewItem67,
            listViewItem68,
            listViewItem69,
            listViewItem70,
            listViewItem71,
            listViewItem72,
            listViewItem73,
            listViewItem74,
            listViewItem75});
            this.listViewHerbs.Location = new System.Drawing.Point(12, 29);
            this.listViewHerbs.Name = "listViewHerbs";
            this.listViewHerbs.ShowItemToolTips = true;
            this.listViewHerbs.Size = new System.Drawing.Size(223, 283);
            this.listViewHerbs.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listViewHerbs.TabIndex = 0;
            this.listViewHerbs.UseCompatibleStateImageBehavior = false;
            this.listViewHerbs.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 200;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Что пилим:";
            // 
            // buttonSelectAll
            // 
            this.buttonSelectAll.Location = new System.Drawing.Point(241, 246);
            this.buttonSelectAll.Name = "buttonSelectAll";
            this.buttonSelectAll.Size = new System.Drawing.Size(132, 23);
            this.buttonSelectAll.TabIndex = 2;
            this.buttonSelectAll.Text = "Отметить все травы";
            this.buttonSelectAll.UseVisualStyleBackColor = true;
            this.buttonSelectAll.Click += new System.EventHandler(this.buttonSelectAll_Click);
            // 
            // buttonUnselectAll
            // 
            this.buttonUnselectAll.Location = new System.Drawing.Point(241, 275);
            this.buttonUnselectAll.Name = "buttonUnselectAll";
            this.buttonUnselectAll.Size = new System.Drawing.Size(132, 23);
            this.buttonUnselectAll.TabIndex = 3;
            this.buttonUnselectAll.Text = "Снять все отметки";
            this.buttonUnselectAll.UseVisualStyleBackColor = true;
            this.buttonUnselectAll.Click += new System.EventHandler(this.buttonUnselectAll_Click);
            // 
            // buttonAccept
            // 
            this.buttonAccept.Location = new System.Drawing.Point(167, 330);
            this.buttonAccept.Name = "buttonAccept";
            this.buttonAccept.Size = new System.Drawing.Size(98, 23);
            this.buttonAccept.TabIndex = 4;
            this.buttonAccept.Text = "Сохранить";
            this.buttonAccept.UseVisualStyleBackColor = true;
            this.buttonAccept.Click += new System.EventHandler(this.buttonAccept_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(271, 330);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(98, 23);
            this.buttonCancel.TabIndex = 5;
            this.buttonCancel.Text = "Отменить";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // checkDoAutoCutWriteChat
            // 
            this.checkDoAutoCutWriteChat.AutoSize = true;
            this.checkDoAutoCutWriteChat.Location = new System.Drawing.Point(241, 212);
            this.checkDoAutoCutWriteChat.Name = "checkDoAutoCutWriteChat";
            this.checkDoAutoCutWriteChat.Size = new System.Drawing.Size(163, 17);
            this.checkDoAutoCutWriteChat.TabIndex = 6;
            this.checkDoAutoCutWriteChat.Text = "Выводить в чат результат";
            this.checkDoAutoCutWriteChat.UseVisualStyleBackColor = true;
            // 
            // FormSettingsAutoCut
            // 
            this.AcceptButton = this.buttonAccept;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.ClientSize = new System.Drawing.Size(410, 367);
            this.Controls.Add(this.checkDoAutoCutWriteChat);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonAccept);
            this.Controls.Add(this.buttonUnselectAll);
            this.Controls.Add(this.buttonSelectAll);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listViewHerbs);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = global::ABClient.Properties.Resources.ABClientIcon;
            this.MaximizeBox = false;
            this.Name = "FormSettingsAutoCut";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Настройки автоспила";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listViewHerbs;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonSelectAll;
        private System.Windows.Forms.Button buttonUnselectAll;
        private System.Windows.Forms.Button buttonAccept;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.CheckBox checkDoAutoCutWriteChat;
    }
}