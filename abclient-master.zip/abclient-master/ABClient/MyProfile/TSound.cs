﻿namespace ABClient.Profile
{
    public struct TSound
    {
        public bool Enabled;
        public bool DoPlayDigits;
        public bool DoPlayAttack;
        public bool DoPlaySndMsg;
        public bool DoPlayRefresh;
        public bool DoPlayAlarm;
        public bool DoPlayTimer;
    }
}