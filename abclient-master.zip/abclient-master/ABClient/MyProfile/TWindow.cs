﻿namespace ABClient.MyProfile
{
    using System.Windows.Forms;

    internal struct TWindow
    {
        internal FormWindowState State;
        internal int Left;
        internal int Top;
        internal int Width;
        internal int Height;
    }
}