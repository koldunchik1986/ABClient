﻿namespace ABClient.MyProfile
{
    public struct TSplitter
    {
        public int Width;
        public bool Collapsed;
    }
}