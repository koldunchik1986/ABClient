﻿namespace ABClient.MyProfile
{
    public struct TNavigator
    {
        public bool AllowTeleports;
    }
}