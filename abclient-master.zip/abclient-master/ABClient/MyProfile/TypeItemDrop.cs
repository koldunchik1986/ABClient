﻿namespace ABClient.MyProfile
{
    internal sealed class TypeItemDrop
    {
        internal string Name;
        internal int Count;
    }
}
