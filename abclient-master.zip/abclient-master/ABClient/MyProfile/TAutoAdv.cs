﻿namespace ABClient.Profile
{
    internal struct TAutoAdv
    {
        internal int Sec;
        internal string Phraz;
    }
}