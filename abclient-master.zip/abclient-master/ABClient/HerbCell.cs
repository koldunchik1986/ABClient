﻿namespace ABClient
{
    internal class HerbCell
    {
        internal string RegNum;
        internal string Herbs;
        internal long UpdatedInTicks;
    }
}
