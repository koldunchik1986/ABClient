﻿namespace ABClient.AppControls
{
    public enum SplitterVisualStyle
    {
        NonMicrosoft = 0,
        XP,
        Win9X,
        DoubleDots,
        Lines
    }
}