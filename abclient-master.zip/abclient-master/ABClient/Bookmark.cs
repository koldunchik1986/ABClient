﻿using System.Drawing;

namespace ABClient
{
    internal class Bookmark
    {
        internal string Title;
        internal string Url;
        internal Image SmallIcon;
    }
}
