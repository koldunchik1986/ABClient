<html>
<head>
<title>ABClient</title>
</head>
<body>
<span id=ev><?php echo(base64_encode("2.19.4|2.28.3|2.31.0|2.31.1|2.31.2|2.31.3|2.31.4|2.32.0|" . date("dmy")));?></span>
<span id=lv><?php echo(base64_encode("2.31.3|" . date("dmy"))); ?></span>
</body>
</html>